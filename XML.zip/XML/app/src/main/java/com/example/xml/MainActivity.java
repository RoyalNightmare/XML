package com.example.xml;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class MainActivity extends AppCompatActivity {
    Button JSONBtn,XMLBtn;
    TextView JSONtv,XMLtv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        JSONBtn = findViewById(R.id.button);
        XMLBtn = findViewById(R.id.button2);
        JSONtv = findViewById(R.id.jsontext);
        XMLtv = findViewById(R.id.Xmldata);

        JSONBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                JSONtv.setText("");
                parseJSON();
            }
        });
        XMLBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                XMLtv.setText("");
                parseXML();
            }
        });
    }

    private void parseXML() {
        try {
            InputStream is = getAssets().open("input.xml");
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();
            Document doc = builder.parse(is);
            Element element = doc.getDocumentElement();
            element.normalize();
            NodeList nList = doc.getElementsByTagName("city");
            for(int i=0;i<nList.getLength();i++)
            {
                Node node = nList.item(i);
                if(node.getNodeType()== Node.ELEMENT_NODE)
                {
                    Element ele2 = (Element) node;
                    XMLtv.append("city:"+getValue("cityName",ele2)+"\n");
                    XMLtv.append("latitude:"+getValue("latitude",ele2)+"\n");
                    XMLtv.append("longitude:"+getValue("longitude",ele2)+"\n");
                    XMLtv.append("temperature:"+getValue("temp",ele2)+"\n");
                    XMLtv.append("humidity:"+getValue("humidity",ele2)+"\n");
                }
            }



        } catch (IOException | ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }

    }

    private String getValue(String cityName, Element ele2) {
        NodeList nodeList = ele2.getElementsByTagName(cityName).item(0).getChildNodes();
        Node node = nodeList.item(0);
        return node.getNodeValue();
    }

    private void parseJSON() {
        try{
            InputStream inputStream = getAssets().open("input.json");
            byte [] data = new byte[inputStream.available()];
            inputStream.read(data);
            String datas = new String(data);
            JSONObject jsonObject = new JSONObject(datas);
            JSONArray jsonArray = jsonObject.getJSONArray("city");
            for(int i=0;i<jsonArray.length();i++)
            {
                JSONObject city = jsonArray.getJSONObject(i);
                JSONtv.append("city:"+city.getString("cityName")+"\n");
                JSONtv.append("latitude:"+city.getString("latitude")+"\n");
                JSONtv.append("longitude:"+city.getString("longitude")+"\n");
                JSONtv.append("temperature:"+city.getString("temp")+"\n");
                JSONtv.append("humidity:"+city.getString("humidity")+"\n");
            }


        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
}